<template>

    <footer class="p-4 bg-gray-500  shadow md:flex md:items-center md:justify-center md:p-6 dark:bg-black">
    <span class="text-sm text-gray-500 sm:text-center text-black">© 2022 <a href="#" class="hover:underline">Akshay™</a>. All Rights Reserved.
    </span>
    </footer>

</template>
