<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Sport;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;

class HomeController extends Controller
{
    public function index()
    {
        $data['sports'] = Sport::active()->get()->count();
        $data['users']= User::all()->count();
        return Inertia::render('Admin/Dashboard',['dash'=>$data]);
    }
}
